package com.banxue.utils;
/**
作者：fengchase
时间：2018年7月17日
文件：ResultCode.java
项目：banxue-backend
*/
public class ResultCode {
	/**
	 * 成功
	 */
	public static String SUCCESS_CODE="000000";
	public static String SUCCESS_MSG="调用成功";
	/**
	 * 失败，普通的失败信息
	 */
	public static String ERROR_CODE="000001";
	public static String ERROR_MSG="调用异常";

}

