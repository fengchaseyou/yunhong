package com.banxue.utils.pay.ali;
/**
作者：fengchase
时间：2018年7月17日
文件：PayException.java
项目：banxue-backend
*/
public class PayException extends Exception {
	
	public PayException(String msg) {
		super(msg);
	}

}

