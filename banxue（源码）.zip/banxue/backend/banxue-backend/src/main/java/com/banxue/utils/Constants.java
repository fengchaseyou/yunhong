package com.banxue.utils;
/**
作者：fengchase
时间：2018年7月11日
文件：Constants.java
项目：banxue-backend
*/
public class Constants {
	
	public static String[] ORDERSTATE= {"初始","支付中","已支付","完成","失效"};
	

}

