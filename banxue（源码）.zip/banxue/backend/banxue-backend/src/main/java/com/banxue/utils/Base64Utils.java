package com.banxue.utils;

public class Base64Utils {
	
}
